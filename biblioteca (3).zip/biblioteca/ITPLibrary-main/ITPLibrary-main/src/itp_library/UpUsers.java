
package itp_library;

import java.awt.BorderLayout;
import java.awt.Color;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JPanel;
import static itp_library.Dashboard.content;
import java.sql.Statement;

public class UpUsers extends javax.swing.JPanel {

    Connect conn;
    Connection reg;
    boolean edit;
    String idus;

    public UpUsers() {
        initComponents();
        conn = new Connect();
        reg = conn.getConnection();
        edit = false;
    }
    
    public UpUsers(String usid, String usname, String usap1, String usap2, String usdom, String ustel) {
        initComponents();
        conn = new Connect();
        reg = conn.getConnection();
        idus = usid;
        name.setText(usname);
        ap1.setText(usap1);
        ap2.setText(usap2);
        dom.setText(usdom);
        tel.setText(ustel);
        edit = true;
        jLabel1.setText("Guardar");
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        body = new javax.swing.JPanel();
        Title = new javax.swing.JLabel();
        Text1 = new javax.swing.JLabel();
        Text2 = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        jSeparator2 = new javax.swing.JSeparator();
        jSeparator3 = new javax.swing.JSeparator();
        tel = new javax.swing.JTextField();
        dom = new javax.swing.JTextField();
        button = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        Text3 = new javax.swing.JLabel();
        name = new javax.swing.JTextField();
        jSeparator4 = new javax.swing.JSeparator();
        Text4 = new javax.swing.JLabel();
        ap1 = new javax.swing.JTextField();
        jSeparator5 = new javax.swing.JSeparator();
        Text5 = new javax.swing.JLabel();
        ap2 = new javax.swing.JTextField();
        jSeparator6 = new javax.swing.JSeparator();

        setBackground(new java.awt.Color(255, 255, 255));
        setMinimumSize(new java.awt.Dimension(750, 430));
        setPreferredSize(new java.awt.Dimension(750, 430));
        setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        body.setBackground(new java.awt.Color(255, 255, 255));
        body.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        add(body, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        Title.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        Title.setText("Registrar nuevo Usuario");
        add(Title, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, -1, -1));

        Text1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        Text1.setText("Teléfono");
        add(Text1, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 150, -1, -1));

        Text2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        Text2.setText("Domicilio");
        add(Text2, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 50, -1, -1));

        jSeparator1.setForeground(new java.awt.Color(255, 204, 0));
        jSeparator1.setPreferredSize(new java.awt.Dimension(200, 10));
        add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 210, 260, 10));

        jSeparator2.setForeground(new java.awt.Color(255, 204, 0));
        jSeparator2.setPreferredSize(new java.awt.Dimension(200, 10));
        add(jSeparator2, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 110, 260, 10));

        jSeparator3.setForeground(new java.awt.Color(204, 204, 204));
        jSeparator3.setOrientation(javax.swing.SwingConstants.VERTICAL);
        jSeparator3.setPreferredSize(new java.awt.Dimension(200, 10));
        add(jSeparator3, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 20, 10, 350));

        tel.setFont(new java.awt.Font("Segoe UI", 0, 12)); // NOI18N
        tel.setForeground(new java.awt.Color(102, 102, 102));
        tel.setText("Ingrese un número telefónico");
        tel.setBorder(null);
        tel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                telMousePressed(evt);
            }
        });
        tel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                telActionPerformed(evt);
            }
        });
        add(tel, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 180, 260, 30));

        dom.setFont(new java.awt.Font("Segoe UI", 0, 12)); // NOI18N
        dom.setForeground(new java.awt.Color(102, 102, 102));
        dom.setText("Ingrese el domicilio");
        dom.setBorder(null);
        dom.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                domMousePressed(evt);
            }
        });
        dom.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                domActionPerformed(evt);
            }
        });
        add(dom, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 80, 260, 30));

        button.setBackground(new java.awt.Color(255, 204, 0));
        button.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                buttonMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                buttonMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                buttonMousePressed(evt);
            }
        });
        button.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Registrar");
        button.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 10, -1, -1));

        add(button, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 270, 260, 50));

        Text3.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        Text3.setText("Nombre");
        add(Text3, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 60, -1, -1));

        name.setFont(new java.awt.Font("Segoe UI", 0, 12)); // NOI18N
        name.setForeground(new java.awt.Color(102, 102, 102));
        name.setText("Ingrese el nombre");
        name.setBorder(null);
        name.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                nameMousePressed(evt);
            }
        });
        name.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nameActionPerformed(evt);
            }
        });
        add(name, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 90, 260, 30));

        jSeparator4.setForeground(new java.awt.Color(255, 204, 0));
        jSeparator4.setPreferredSize(new java.awt.Dimension(200, 10));
        add(jSeparator4, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 120, 260, 10));

        Text4.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        Text4.setText("Apellido Paterno");
        add(Text4, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 160, -1, -1));

        ap1.setFont(new java.awt.Font("Segoe UI", 0, 12)); // NOI18N
        ap1.setForeground(new java.awt.Color(102, 102, 102));
        ap1.setText("Ingrese el apellido paterno");
        ap1.setBorder(null);
        ap1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                ap1MousePressed(evt);
            }
        });
        ap1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ap1ActionPerformed(evt);
            }
        });
        add(ap1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 190, 260, 30));

        jSeparator5.setForeground(new java.awt.Color(255, 204, 0));
        jSeparator5.setPreferredSize(new java.awt.Dimension(200, 10));
        add(jSeparator5, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 220, 260, 10));

        Text5.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        Text5.setText("Apellido Materno");
        add(Text5, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 260, -1, -1));

        ap2.setFont(new java.awt.Font("Segoe UI", 0, 12)); // NOI18N
        ap2.setForeground(new java.awt.Color(102, 102, 102));
        ap2.setText("Ingrese el apellido materno");
        ap2.setBorder(null);
        ap2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                ap2MousePressed(evt);
            }
        });
        ap2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ap2ActionPerformed(evt);
            }
        });
        add(ap2, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 290, 260, 30));

        jSeparator6.setForeground(new java.awt.Color(255, 204, 0));
        jSeparator6.setPreferredSize(new java.awt.Dimension(200, 10));
        add(jSeparator6, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 320, 260, 10));
    }// </editor-fold>//GEN-END:initComponents

    private void telActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_telActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_telActionPerformed

    private void domMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_domMousePressed
       
       if(name.getText().equals("") || name.getText() == null || name.getText().equals(" "))
        name.setText("Ingrese el nombre");
       if(ap1.getText().equals("") || ap1.getText() == null || ap1.getText().equals(" "))
        ap1.setText("Ingrese el apellido paterno");
       if(ap2.getText().equals("") || ap2.getText() == null || ap2.getText().equals(" "))
        ap2.setText("Ingrese el apellido materno");
       if(dom.getText().equals("Ingrese el domicilio"))
        dom.setText("");
       if(tel.getText().equals("") || tel.getText() == null || tel.getText().equals(" "))
        tel.setText("Ingrese un número telefónico");
    }//GEN-LAST:event_domMousePressed

    private void telMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_telMousePressed
        if(name.getText().equals("") || name.getText() == null || name.getText().equals(" "))
        name.setText("Ingrese el nombre");
       if(ap1.getText().equals("") || ap1.getText() == null || ap1.getText().equals(" "))
        ap1.setText("Ingrese el apellido paterno");
       if(ap2.getText().equals("") || ap2.getText() == null || ap2.getText().equals(" "))
        ap2.setText("Ingrese el apellido materno");
       if(dom.getText().equals("") || dom.getText() == null || dom.getText().equals(" "))
        dom.setText("Ingrese el domicilio");
       if(tel.getText().equals("Ingrese un número telefónico"))
        tel.setText("");
    }//GEN-LAST:event_telMousePressed

    private void buttonMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_buttonMouseEntered
        setColor(button);
    }//GEN-LAST:event_buttonMouseEntered

    private void buttonMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_buttonMouseExited
        resetColor(button);
    }//GEN-LAST:event_buttonMouseExited

    private void nameMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_nameMousePressed
        if(name.getText().equals("Ingrese el nombre"))
        name.setText("");
       if(ap1.getText().equals("") || ap1.getText() == null || ap1.getText().equals(" "))
        ap1.setText("Ingrese el apellido paterno");
       if(ap2.getText().equals("") || ap2.getText() == null || ap2.getText().equals(" "))
        ap2.setText("Ingrese el apellido materno");
       if(dom.getText().equals("") || dom.getText() == null || dom.getText().equals(" "))
        dom.setText("Ingrese el domicilio");
       if(tel.getText().equals("") || tel.getText() == null || tel.getText().equals(" "))
        tel.setText("Ingrese un número telefónico");
    }//GEN-LAST:event_nameMousePressed

    private void ap1MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ap1MousePressed
        if(name.getText().equals("") || name.getText() == null || name.getText().equals(" "))
        name.setText("Ingrese el nombre");
       if(ap1.getText().equals("Ingrese el apellido paterno"))
        ap1.setText("");
       if(ap2.getText().equals("") || ap2.getText() == null || ap2.getText().equals(" "))
        ap2.setText("Ingrese el apellido materno");
       if(dom.getText().equals("") || dom.getText() == null || dom.getText().equals(" "))
        dom.setText("Ingrese el domicilio");
       if(tel.getText().equals("") || tel.getText() == null || tel.getText().equals(" "))
        tel.setText("Ingrese un número telefónico");
    }//GEN-LAST:event_ap1MousePressed

    private void ap1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ap1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ap1ActionPerformed

    private void ap2MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ap2MousePressed
       if(name.getText().equals("") || name.getText() == null || name.getText().equals(" "))
        name.setText("Ingrese el nombre");
       if(ap2.getText().equals("Ingrese el apellido materno"))
        ap2.setText("");
       if(ap1.getText().equals("") || ap1.getText() == null || ap1.getText().equals(" "))
        ap1.setText("Ingrese el apellido paterno");
       if(dom.getText().equals("") || dom.getText() == null || dom.getText().equals(" "))
        dom.setText("Ingrese el domicilio");
       if(tel.getText().equals("") || tel.getText() == null || tel.getText().equals(" "))
        tel.setText("Ingrese un número telefónico");
    }//GEN-LAST:event_ap2MousePressed

    private void ap2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ap2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ap2ActionPerformed

    private void nameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_nameActionPerformed

    private void domActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_domActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_domActionPerformed
    


// REGISTRAR
    private void buttonMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_buttonMousePressed
        if(name.getText().equals("Ingrese el nombre") || ap1.getText().equals("Ingrese el apellido paterno")
            || ap2.getText().equals("Ingrese el apellido materno") || dom.getText().equals("Ingrese el domicilio")
            || tel.getText().equals("Ingrese un número telefónico")){
            javax.swing.JOptionPane.showMessageDialog(this, "Debe llenar todos los campos \n", "AVISO", javax.swing.JOptionPane.INFORMATION_MESSAGE);
            name.requestFocus();
        }
        else
        {
            String uname = name.getText();
            String uapp = ap1.getText();
            String uapm = ap2.getText();
            String udom = dom.getText();
            String utel = tel.getText();

            if(uname == null || "".equals(uname) || uapp == null || "".equals(uapp) || uapm == null || "".equals(uapm) || udom == null || "".equals(udom) || utel == null || "".equals(utel)){
                javax.swing.JOptionPane.showMessageDialog(this, "Debe llenar todos los campos \n", "AVISO", javax.swing.JOptionPane.INFORMATION_MESSAGE);
                name.requestFocus();
            }
            else{ 
                try {
                    if(edit)
                        EditUser(idus, uname, uapp, uapm, udom, utel);
                    else
                        InsertUser(uname, uapp, uapm, udom, utel);

                    name.setText("");
                    ap1.setText("");
                    ap2.setText("");
                    dom.setText("");
                    tel.setText("");

                    if(edit){
                        Users p1 = new Users();
                        p1.setSize(750, 430);
                        p1.setLocation(0, 0);

                        content.removeAll();
                        content.add(p1, BorderLayout.CENTER);
                        content.revalidate();
                        content.repaint();
                    }
                } catch (SQLException ex) {
                    Logger.getLogger(UpUsers.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
    }//GEN-LAST:event_buttonMousePressed

    void setColor(JPanel panel){
        panel.setBackground(new Color(255,170,3));
    }
    void resetColor(JPanel panel){
        panel.setBackground(new Color(255,204,0));
    }
    
    //INSERTAR
    public void InsertUser(String name, String app, String apm, String dom, String tel) throws SQLException{
        Statement stm = reg.createStatement();
        
        stm.executeUpdate("INSERT INTO `users` (`name`, `last_name_p`, `last_name_m`, `domicilio`, `tel`) VALUES ('"+name+"', '"+app+"', '"+ apm +"', '"+ dom +"', '"+tel+"')");
        javax.swing.JOptionPane.showMessageDialog(this, "¡Usuario registrado correctamente! \n", "HECHO", javax.swing.JOptionPane.INFORMATION_MESSAGE);
        
    }
    
    //EDITAR
    public void EditUser(String id, String name, String app, String apm, String dom, String tel) throws SQLException{
        Statement stm = reg.createStatement();
        
        stm.executeUpdate("UPDATE `users` SET `name` = '"+name+"', `last_name_p` = '"+app+"', `last_name_m` = '"+apm+"', `domicilio` = '"+dom+"', `tel` = '"+tel+"' WHERE `id` = "+ id +";");
        javax.swing.JOptionPane.showMessageDialog(this, "¡Usuario editado correctamente! \n", "HECHO", javax.swing.JOptionPane.INFORMATION_MESSAGE);
        
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Text1;
    private javax.swing.JLabel Text2;
    private javax.swing.JLabel Text3;
    private javax.swing.JLabel Text4;
    private javax.swing.JLabel Text5;
    private javax.swing.JLabel Title;
    private javax.swing.JTextField ap1;
    private javax.swing.JTextField ap2;
    private javax.swing.JPanel body;
    private javax.swing.JPanel button;
    private javax.swing.JTextField dom;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JSeparator jSeparator3;
    private javax.swing.JSeparator jSeparator4;
    private javax.swing.JSeparator jSeparator5;
    private javax.swing.JSeparator jSeparator6;
    private javax.swing.JTextField name;
    private javax.swing.JTextField tel;
    // End of variables declaration//GEN-END:variables
}
